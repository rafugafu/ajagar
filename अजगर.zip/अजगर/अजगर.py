import sys
import os
import re
try:
    from termcolor import colored
except:
    def colored(string, color, attrs):
        return string
from runnerpython import run
def translate(code):
    translations = {
        'अगर': 'if', 'नहीतो': 'else', 'नहीऔर': 'elif', 'कोशिश': 'try', 'अपवाद': 'except',
        'आयात': 'import', 'बोल': 'print', 'खतम': 'exit', 'खुला': 'open', 'गलत': 'False',
        'सही': 'True', 'खाली': 'None', 'और': 'and', 'जैसा': 'as', 'ज़ोर': 'assert',
        'तोड': 'break', r'कक्षा': 'class', 'आगे': 'continue', r'परिभाषा': 'def', 'मिटा': 'del',
        'बादमे': 'finally', 'हरएक': 'for', 'से': 'from', 'वैश्विक': 'global', 'अन्दर': 'in',
        'हैय': 'is', 'बाहर': 'nonlocal', 'उलटा': 'not', 'यातो': 'or', 'जानेदो': 'pass',
        'उठा': 'raise', 'भेज': 'return', 'जबतक': 'while', 'केसाथ': 'with',
        'इसकेजगह': 'replace', 'पूछ': 'input', 'छोटा': 'lower', 'बडा': 'upper', 'खुद': 'self',
        '१': '1', '२': '2', '३': '3', '४': '4', '५': '5', '६': '6',
        '७': '7', '८': '8', '९': '9', '०': '0', 'श्रेणी': 'range'
    }
    for key in list(translations.keys()):
        code = code.replace(key, translations[key])
    return code
def translateback(string = None):
    string = str(string)
    if not string:
        return
    translations = {
        '1': '१', '2': '२', '3': '३', '4': '४', '5': '५', '6': '६',
        '7': '७', '8': '८', '9': '९', '0': '०', 'True': 'सही', 'False': 'गलत'
    }
    for key in list(translations.keys()):
        string = string.replace(key, translations[key])
    return string
def filerun(file):
    file = open(file, 'r')
    code = translate(file.read())
    file.close()
    output = run(translate(code))
    if output[0] == True:
        print('इसमे गलती है:\n')
        print(output[1])
    else:
        printable = list(map(translateback, output[1]))
        for line in printable:
            print(line)
def shell(oldcode = '', contin = False):
    while True:
        if contin == False:
            oldcode = ''
            code = translate(input(colored('>>> ', 'red', attrs = ['bold'])))
            if oldcode:
                code = oldcode + '\n' + code
            oldcode = code
            if code[-1:] == ':':
                contin = True
            else:
                output = run(translate(code))
                if output[0]:
                    print('इसमे गलती है:\n')
                    print(output[1])
                else:
                    printable = list(map(translateback, output[1]))
                    for line in printable:
                        print(line)
        else:
            code = translate(input(colored('... ', 'red', attrs = ['bold'])))
            if code == '':
                output = run(translate(oldcode))
                if output[0] == True:
                    print('इसमे गलती है:\n')
                    print(output[1])
                else:
                    printable = list(map(translateback, output[1]))
                    for line in printable:
                        print(line)
                contin = False
                oldcode = ''
            if oldcode:
                code = oldcode + '\n' + code
            oldcode = code
if sys.argv[1:]:
    for item in sys.argv[1:]:
        if os.path.exists(item):
            filerun(item)
        else:
            os.system(f'python3 {item}')
else:
    shell()